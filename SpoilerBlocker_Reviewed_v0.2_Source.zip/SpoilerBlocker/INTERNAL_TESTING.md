# Install SpoilerBlocker v0.2 from Google Play (Internal App Sharing)

**Why:** Play Protect may block an app installed through WhatsApp or a browser when it requests Android Accessibility. Do not turn off Play Protect or try to work around device security.

**Needed:** A Google Play Console developer account (Google currently charges a **US$25 one-time registration fee**) and permission to upload internal test builds. If you don't have an account yet, create one at https://play.google.com/console/signup . Account setup and verification are controlled by Google.

## 1. Build the app on GitHub

1. Download `SpoilerBlocker_Reviewed_v0.2_Source.zip` supplied in ChatGPT.
2. Open your repository `Spoilet-blocker-v1` → **Code** → **Add file** → **Upload files** and upload that ZIP. Commit it.
3. Open `.github/workflows/build.yml` in the repository and choose **Edit** (pencil).
4. Replace its contents with the separate file `SpoilerBlocker_v0.2_build.yml` supplied with the source. Commit it.
5. Go to **Actions** and open the most recent run. When it succeeds, open the run summary → **Artifacts**. Download **SpoilerBlocker-v0.2-APK** and extract `app-debug.apk`.

The workflow also offers a test `.aab` artifact. Internal App Sharing accepts debug APKs or app bundles. **Do not upload this debug build as a production release.**

## 2. Share the APK through Google Play

1. Sign into https://play.google.com/console using the developer account.
2. Open or create the SpoilerBlocker app entry as required by the Console. Find **Internal app sharing** under **Test and release → Internal testing** (the navigation may vary).
3. Authorize yourself as an uploader and enable appropriate tester access. Google Play controls this account setup.
4. Open the Console's **Internal App Sharing upload page** and upload `app-debug.apk`. Google automatically re-signs internal-sharing uploads. Copy the generated share link.
5. On the Android test phone, in **Play Store → Settings → About**, tap **Play Store version** seven times, then enable **Internal app sharing** when the option appears.
6. Open the generated link on your phone in the same Google account authorized for testing. Follow the Google Play installation flow.

**Important:** Internal App Sharing is not Play Store publication or security certification, and Google can still refuse an upload/install or require app settings. Internal sharing URLs expire after 60 days, and each link supports up to 100 downloads. Account registration/payment and app verification are not performed by ChatGPT.

## 3. Enable and test the service

1. Open SpoilerBlocker, review the separate Accessibility disclosure, and explicitly accept it if you wish.
2. Enable its Accessibility service through Android Settings as directed.
3. Add test keywords: `Avengers`, `Doomsday`, `Marvel`.
4. Use **Test a caption against your keywords** and **Preview spoiler warning** inside SpoilerBlocker first.
5. Open TikTok and test detection. The filter is text-only, beta, and may miss content or display the warning too late. Never deliberately rely on it to prevent a major spoiler until its behavior is proven on your phone.
6. Return to SpoilerBlocker to turn it off, review consent, or withdraw consent.

## Play policy before any public/production release

SpoilerBlocker is **not** a disability-focused Accessibility tool. Do **not** claim `isAccessibilityTool=true`. A general utility using Accessibility must provide prominent in-app data disclosure, affirmative user consent, and a Google Play Console Accessibility permission declaration; review may require a demonstration video. See https://support.google.com/googleplay/android-developer/answer/10964491 . Public distribution may also require a valid privacy-policy URL, developer contact information, proper release signing, store listing, declarations, and additional testing.
