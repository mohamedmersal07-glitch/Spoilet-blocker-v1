# SpoilerBlocker v0.2 — TikTok test prototype

SpoilerBlocker is an independent **Android test app** that attempts to show a spoiler warning over TikTok when captions or other accessible text match blocked keywords. It can also attempt a single swipe when the user taps **Skip video**, or let the user tap **View anyway**.

This is **not a guaranteed spoiler filter**. TikTok may play content before the warning appears, and spoilers in audio or images may be missed.

## What's in the project

- `app/` — Java Android source code, keyword settings UI, in-app Accessibility disclosure, TikTok text-scanning service and warning overlay
- `INTERNAL_TESTING.md` — build and install using GitHub Actions and **Google Play Internal App Sharing**
- `SECURITY_REVIEW.md` — manual source and permission review and known limitations
- `PRIVACY_POLICY.md` — test version's privacy details
- `scripts/test-matcher.sh` — 10 Java keyword-matching tests

## What was changed since v0.1

The invalid Android Accessibility XML attribute was corrected in source; consent details were expanded; withdrawal of consent was added; version became 0.2.0.

## Build status

Automated Java keyword matcher tests: **10 passed**. Android XML parsed and passed basic static checks. This package was **not compiled or device-tested here** because the required Android SDK and Gradle are not installed in this environment. The user previously showed a successful GitHub Actions build of the v0.1 source after the XML attribute was fixed at build time. Compile this version through the supplied GitHub workflow before installing.

## Privacy

No Internet, SMS, contacts or storage permission is requested by the reviewed source. TikTok text is compared on-device and not stored. Only blocked terms and configuration/consent flags are saved locally. Because Accessibility is a sensitive Android feature, follow the separate in-app consent and use a controlled Google Play testing path rather than disabling security checks.

SpoilerBlocker is not affiliated with TikTok or Google.
