package com.spoilerblocker.app;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 15, 25);
    private static final int CARD = Color.rgb(22, 30, 43);
    private static final int ACCENT = Color.rgb(101, 231, 207);
    private static final int WHITE = Color.rgb(241, 246, 252);
    private static final int MUTED = Color.rgb(161, 174, 192);
    private SettingsStore store;
    private Switch powerSwitch;
    private TextView statusText;
    private LinearLayout keywordList;
    private EditText termInput;
    private Button permissionButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        store = new SettingsStore(this);
        buildScreen();
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        if (powerSwitch != null) refresh();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout screen = column();
        screen.setPadding(dp(22), dp(24), dp(22), dp(32));
        scroll.addView(screen);
        setContentView(scroll);

        LinearLayout brand = row();
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(com.spoilerblocker.app.R.drawable.ic_shield);
        brand.addView(logo, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout brandText = column();
        brandText.setPadding(dp(11), 0, 0, 0);
        brandText.addView(label("SpoilerBlocker", 22, WHITE, true));
        brandText.addView(label("YOUR FEED. YOUR RULES.", 10, ACCENT, true));
        brand.addView(brandText);
        screen.addView(brand);

        space(screen, 28);
        TextView beta = label("TIKTOK  /  EARLY ACCESS", 11, ACCENT, true);
        screen.addView(beta);
        space(screen, 9);
        screen.addView(label("Protect the plot.\nEnjoy the scroll.", 30, WHITE, true));
        space(screen, 9);
        screen.addView(label("Add anything you don't want spoiled. We'll watch the text TikTok makes available and warn you on a match.", 14, MUTED, false));
        space(screen, 25);

        LinearLayout controlCard = card();
        LinearLayout controlRow = row();
        controlRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout controlText = column();
        controlText.addView(label("Spoiler protection", 18, WHITE, true));
        controlText.addView(label("One switch. More peace of mind.", 12, MUTED, false));
        controlRow.addView(controlText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        powerSwitch = new Switch(this);
        powerSwitch.setThumbTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}}, new int[]{ACCENT, MUTED}));
        powerSwitch.setTrackTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}}, new int[]{0xFF376B67, 0xFF3E4755}));
        controlRow.addView(powerSwitch);
        controlCard.addView(controlRow);
        space(controlCard, 15);
        View rule = new View(this);
        rule.setBackgroundColor(0xFF2E3C50);
        controlCard.addView(rule, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        space(controlCard, 14);
        statusText = label("Checking setup…", 13, MUTED, false);
        controlCard.addView(statusText);
        space(controlCard, 13);
        permissionButton = actionButton("Enable Android access", true);
        controlCard.addView(permissionButton);
        permissionButton.setOnClickListener(v -> requestPermission());
        screen.addView(controlCard);

        space(screen, 25);
        screen.addView(label("Blocked keywords", 21, WHITE, true));
        space(screen, 6);
        screen.addView(label("Use titles, names, or phrases. Matching ignores letter case.", 13, MUTED, false));
        space(screen, 12);
        keywordList = column();
        screen.addView(keywordList);
        space(screen, 12);

        LinearLayout addRow = row();
        addRow.setGravity(Gravity.CENTER_VERTICAL);
        termInput = new EditText(this);
        termInput.setSingleLine(true);
        termInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        termInput.setHint("e.g. Avengers Doomsday");
        termInput.setHintTextColor(0xFF8395A9);
        termInput.setTextColor(WHITE);
        termInput.setTextSize(14);
        termInput.setPadding(dp(14), dp(8), dp(12), dp(8));
        termInput.setBackground(surface(CARD, 12, 0xFF384457));
        addRow.addView(termInput, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button add = actionButton("Add", true);
        LinearLayout.LayoutParams addParams = new LinearLayout.LayoutParams(dp(79), dp(48));
        addParams.leftMargin = dp(8);
        addRow.addView(add, addParams);
        add.setOnClickListener(v -> addTerm());
        screen.addView(addRow);
        space(screen, 12);
        Button example = actionButton("+ Load Avengers example keywords", false);
        example.setOnClickListener(v -> {
            List<String> terms = new ArrayList<>(store.keywords());
            for (String item : Arrays.asList("Avengers", "Doomsday", "Avengers Doomsday", "Marvel")) {
                if (!containsTerm(terms, item)) terms.add(item);
            }
            store.saveKeywords(terms);
            renderTerms();
        });
        screen.addView(example);

        space(screen, 24);
        LinearLayout previewCard = card();
        previewCard.addView(label("See the warning first", 18, WHITE, true));
        space(previewCard, 5);
        previewCard.addView(label("Preview what appears when a TikTok video contains a blocked keyword.", 13, MUTED, false));
        space(previewCard, 12);
        Button preview = actionButton("Preview spoiler warning", false);
        preview.setOnClickListener(v -> previewWarning());
        previewCard.addView(preview);
        space(previewCard, 8);
        Button testCaption = actionButton("Test a caption against your keywords", false);
        testCaption.setOnClickListener(v -> testCaption());
        previewCard.addView(testCaption);
        space(previewCard, 8);
        Button launch = actionButton("Open TikTok", true);
        launch.setOnClickListener(v -> openTikTok());
        previewCard.addView(launch);
        screen.addView(previewCard);

        space(screen, 22);
        screen.addView(label("YOUR DATA, YOUR CHOICE", 11, ACCENT, true));
        space(screen, 8);
        Button consentDetails = actionButton("Review or withdraw Accessibility consent", false);
        consentDetails.setOnClickListener(v -> reviewConsent());
        screen.addView(consentDetails);
        space(screen, 18);
        screen.addView(label("PRIVACY FIRST", 11, ACCENT, true));
        space(screen, 5);
        screen.addView(label("No account. No internet permission. Your keyword list stays on your device. Detection is text-only in version 0.1 and isn't guaranteed to catch spoilers before they appear.", 12, MUTED, false));
        space(screen, 12);
        screen.addView(label("SpoilerBlocker 0.2  ·  Android test build", 11, 0xFF748398, false));

        powerSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (!button.isPressed()) return;
            if (!checked) {
                store.setEnabled(false);
                refresh();
            } else if (!store.hasConsent()) {
                powerSwitch.setChecked(false);
                showConsent();
            } else {
                store.setEnabled(true);
                refresh();
                if (!isServiceActive()) openAccessibilitySettings();
            }
        });
    }

    private void addTerm() {
        String term = termInput.getText().toString().trim();
        if (term.isEmpty()) return;
        if (term.length() > 80) { toast("Please use up to 80 characters."); return; }
        List<String> terms = new ArrayList<>(store.keywords());
        if (terms.size() >= 100) { toast("Maximum of 100 blocked phrases."); return; }
        if (containsTerm(terms, term)) { toast("Already in your list."); return; }
        terms.add(term);
        store.saveKeywords(terms);
        termInput.setText("");
        renderTerms();
        refresh();
    }

    private boolean containsTerm(List<String> list, String term) {
        String normalized = KeywordMatcher.normalize(term);
        for (String value : list) if (KeywordMatcher.normalize(value).equals(normalized)) return true;
        return false;
    }

    private void renderTerms() {
        keywordList.removeAllViews();
        List<String> terms = store.keywords();
        if (terms.isEmpty()) {
            TextView empty = label("No keywords yet. Add a title or load the example.", 13, MUTED, false);
            empty.setPadding(dp(14), dp(18), dp(14), dp(18));
            empty.setBackground(surface(CARD, 12, 0));
            keywordList.addView(empty);
            return;
        }
        for (String term : terms) {
            LinearLayout item = row();
            item.setPadding(dp(14), dp(5), dp(6), dp(5));
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setBackground(surface(CARD, 12, 0xFF384457));
            TextView name = label(term, 14, WHITE, false);
            name.setMaxLines(2);
            item.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            Button remove = actionButton("×", false);
            remove.setTextSize(23);
            item.addView(remove, new LinearLayout.LayoutParams(dp(44), dp(40)));
            remove.setContentDescription("Remove " + term);
            remove.setOnClickListener(v -> {
                List<String> updated = new ArrayList<>(store.keywords());
                updated.remove(term);
                store.saveKeywords(updated);
                renderTerms();
                refresh();
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.bottomMargin = dp(7);
            keywordList.addView(item, params);
        }
    }

    private static final String ACCESS_DISCLOSURE =
            "SpoilerBlocker uses Android Accessibility to inspect text and descriptions exposed by " +
            "TikTok (such as captions, hashtags, and video labels) to compare with your blocked keywords. " +
            "It observes app/window changes to remove warnings when you leave TikTok, but does not inspect " +
            "the text of other apps.\n\n" +
            "It can display a cover over a matching TikTok and swipe past a video only when you tap Skip. " +
            "Scanning is text-only and can miss spoilers or warn after content appears.\n\n" +
            "Matching runs on your device. SpoilerBlocker does not upload, record, or save TikTok text. " +
            "Your selected blocked keywords are saved on this device; no account or internet access is used.\n\n" +
            "You can turn protection off or withdraw consent at any time in SpoilerBlocker, and disable " +
            "the service in Android Accessibility settings.";

    private void showConsent() {
        new AlertDialog.Builder(this)
            .setTitle("Accessibility access: your choice")
            .setMessage(ACCESS_DISCLOSURE + "\n\nDo you agree to this use of Accessibility?")
            .setNegativeButton("Not now", (d, w) -> refresh())
            .setPositiveButton("I agree", (d, w) -> {
                store.acceptConsent();
                store.setEnabled(true);
                refresh();
                if (!isServiceActive()) openAccessibilitySettings();
            }).show();
    }

    private void reviewConsent() {
        new AlertDialog.Builder(this)
            .setTitle("Accessibility & privacy")
            .setMessage(ACCESS_DISCLOSURE)
            .setNeutralButton("Withdraw consent", (d, w) -> {
                store.withdrawConsent();
                refresh();
                toast("Consent withdrawn. Protection is off.");
            })
            .setNegativeButton("Close", null)
            .setPositiveButton("Android settings", (d, w) -> openAccessibilitySettings())
            .show();
    }

    private void requestPermission() {
        if (!store.hasConsent()) showConsent();
        else openAccessibilitySettings();
    }

    private void openAccessibilitySettings() {
        try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
        catch (ActivityNotFoundException e) { toast("Open Settings > Accessibility > SpoilerBlocker."); }
    }

    private boolean isServiceActive() {
        AccessibilityManager manager = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        for (AccessibilityServiceInfo info : manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
            if (info.getId() != null && info.getId().contains(getPackageName() + "/")) {
                if (info.getId().contains("TikTokFilterService")) return true;
            }
        }
        return false;
    }

    private void refresh() {
        powerSwitch.setChecked(store.isEnabled());
        boolean active = isServiceActive();
        if (!store.isEnabled()) {
            statusText.setText("●  OFF  ·  No filtering is running");
            statusText.setTextColor(MUTED);
        } else if (!active) {
            statusText.setText("●  SETUP NEEDED  ·  Enable the Accessibility service");
            statusText.setTextColor(0xFFFFC077);
        } else if (store.keywords().isEmpty()) {
            statusText.setText("●  ON  ·  Add keywords to start detecting");
            statusText.setTextColor(0xFFFFC077);
        } else {
            statusText.setText("●  ON  ·  Watching for TikTok keywords");
            statusText.setTextColor(ACCENT);
        }
        permissionButton.setText(active ? "Accessibility enabled ✓" : "Enable Android access");
        permissionButton.setEnabled(!active);
        renderTerms();
    }

    private void testCaption() {
        EditText caption = new EditText(this);
        caption.setSingleLine(false);
        caption.setMinLines(2);
        caption.setTextColor(WHITE);
        caption.setHint("Example: New Avengers trailer just dropped");
        caption.setHintTextColor(MUTED);
        new AlertDialog.Builder(this)
            .setTitle("Test the spoiler detector")
            .setMessage("Paste a sample caption. Nothing leaves this device.")
            .setView(caption)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Check", (dialog, which) -> {
                String keyword = KeywordMatcher.firstMatch(caption.getText().toString(), store.keywords());
                if (keyword == null) {
                    new AlertDialog.Builder(this).setTitle("No spoiler keywords found")
                        .setMessage("The sample text didn't contain your blocked phrases.")
                        .setPositiveButton("OK", null).show();
                } else {
                    previewWarning(keyword);
                }
            }).show();
    }

    private void previewWarning() { previewWarning("Avengers"); }
    private void previewWarning(String keyword) {
        new AlertDialog.Builder(this)
            .setTitle("⚠  POSSIBLE SPOILER")
            .setMessage("A TikTok video contains text that may be related to one of your blocked topics.\n\nMatched keyword: " + keyword + "\n\nWould you like to view the content anyway?")
            .setNegativeButton("Keep hidden", (d, w) -> toast("Preview only · In TikTok you can skip the video."))
            .setPositiveButton("View anyway", (d, w) -> toast("Preview only · You chose to reveal it."))
            .show();
    }

    private void openTikTok() {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.zhiliaoapp.musically");
        if (intent == null) intent = getPackageManager().getLaunchIntentForPackage("com.ss.android.ugc.trill");
        if (intent != null) startActivity(intent);
        else toast("TikTok isn't installed or couldn't be opened.");
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }
    private LinearLayout card() {
        LinearLayout l = column();
        l.setPadding(dp(17), dp(18), dp(17), dp(18));
        l.setBackground(surface(CARD, 18, 0xFF29394D));
        return l;
    }
    private TextView label(String text, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(color);
        v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setLineSpacing(dp(2), 1.05f);
        return v;
    }
    private Button actionButton(String title, boolean primary) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(title);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? BG : ACCENT);
        b.setBackground(surface(primary ? ACCENT : 0xFF1A2E37, 12, primary ? 0 : 0xFF3B6E68));
        b.setMinHeight(dp(46));
        b.setStateListAnimator(null);
        return b;
    }
    private GradientDrawable surface(int color, float radius, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }
    private void space(LinearLayout l, int height) {
        View v = new View(this);
        l.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }
}
