# SpoilerBlocker — Privacy Information (Test v0.2)

Last updated: November 18, 2026

SpoilerBlocker is an independent, experimental Android utility. It is not affiliated with TikTok.

**What the app accesses:** When you explicitly enable its Android Accessibility service, SpoilerBlocker may receive Accessibility window events. It inspects accessible text and content descriptions from TikTok to compare against blocked keywords. It also observes foreground app changes so it can hide its overlay when TikTok is no longer in front. It does not intentionally inspect text from other apps.

**What the app stores:** Your blocked keyword list, ON/OFF setting, and Accessibility consent setting are stored locally in Android SharedPreferences. The app does not save the text that it reads from TikTok.

**Sharing, collection, and network:** The reviewed test version has no internet permission, account system, analytics, ads, or server upload feature. No user data is sent by SpoilerBlocker to external servers.

**Controls:** Disable Spoiler protection within the app to stop active matching. Use **Review or withdraw Accessibility consent** in the app to withdraw consent. You may also disable SpoilerBlocker under Android Settings → Accessibility at any time. Uninstalling the app removes its local app data under normal Android behavior.

**Limitations:** The app can miss spoilers, alert too late, or warn on unrelated text. It scans only text made available to Accessibility. It is a development test build, not a guarantee of protection.

**Developer contact:** A developer email must be added to the public-facing privacy policy before publishing on Google Play. The test source does not supply one.
