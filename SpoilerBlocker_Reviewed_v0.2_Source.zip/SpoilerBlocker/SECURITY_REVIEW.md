# SpoilerBlocker v0.2 — source and permission review

Reviewed: 2026-11-18. Scope: the v0.1 source files in `SpoilerBlocker_APK_Build_Ready.zip` plus the v0.2 changes. This is a **manual static source review**, not a professional penetration test, malware clearance, or on-device verification.

## Components and permission review

| Item | Observed implementation | Significance |
|---|---|---|
| Android Accessibility service | `TikTokFilterService`, gated by Android's `BIND_ACCESSIBILITY_SERVICE` | Sensitive ability to receive accessibility events and read TikTok's accessible UI tree. Required for prototype; triggers Play Protect safeguards when sideloaded. |
| Accessibility event scope | Service may receive window events across apps, reads *text/content descriptions* only from two TikTok package names, tracks package name of other foreground apps to remove its warning | Other app names may be observed transiently, but their UI text is not scanned or saved. Android service events remain broadly subscribed to avoid the warning getting stuck above another app. |
| Gestures | `canPerformGestures=true` and `dispatchGesture` | Used to swipe only after the user chooses **Skip video**. No autonomous action planning. |
| Overlay | `TYPE_ACCESSIBILITY_OVERLAY` | Covers TikTok when a matching term is detected. No `SYSTEM_ALERT_WINDOW` permission required for this service type. |
| Network access | No `android.permission.INTERNET` declaration and no observed network calls | No direct network permission; still do not assume this proves absence of all risks. |
| Storage, SMS, contacts, notifications | No related permissions | Not requested. |
| Account or advertising | No SDK for tracking, account login, or advertising observed | No observed analytics/uploading mechanism. |
| Persistence | `SettingsStore` stores user blocked phrases, enabled state, consent state in local SharedPreferences | Blocked keywords remain locally stored. TikTok text is not persisted. |
| Backup | `android:allowBackup="false"` | Reduces unintended backup of the preferences. |
| Exported components | Launcher activity is exported; Accessibility service exported but bound with `BIND_ACCESSIBILITY_SERVICE` | Standard Android service declaration. |

## Improvements in v0.2

- Fixed invalid service XML attribute (`android:flags` to `android:accessibilityFlags`) inside the project itself, not only through a build-time workaround.
- Added a dedicated, affirmative Accessibility disclosure and clear notice that app/window activity is observed for dismissing the overlay.
- Added **Review or withdraw Accessibility consent** in the app. Withdrawal disables spoiler filtering and revokes the saved consent bit; the Android Accessibility service can be disabled separately in system settings.
- Bumped version to 0.2.0, versionCode 2.
- Added GitHub Actions workflow for a debug APK and debug AAB to use with Google Play **Internal App Sharing**. A debug build is for private testing, not production publishing.

## Remaining limitations and risks

- A spoiler may appear before text detection or when TikTok does not expose the text in Accessibility.
- Visual or spoken spoilers aren't detected. Keyword matching can cause false positives. The prototype does not guarantee full spoiler protection.
- The `View anyway` override is identified by a text snippet rather than a stable video ID; TikTok UI changes may retrigger it.
- TikTok UI changes and device OEM restrictions can break overlays or gesture behavior.
- Android Accessibility permission is powerful; installing only builds you trust and reviewing their source remains important.
- This project has not been built or device-tested in the current environment; a previous v0.1 with an XML fix built successfully through GitHub Actions as shown by the user.
- Google Play's own policies, permissions declaration and app-review decisions still apply, especially for any later public release.

## Security principles

- No instructions to disable Play Protect or override Android safety features.
- Obtain clear user consent before opening Accessibility settings.
- Do not label this app as `isAccessibilityTool=true`: the application is a general spoiler utility, not a disability-specific tool.
- The app is not affiliated with TikTok, Google, or Marvel.

Sources for distribution requirements:
- https://developers.google.com/android/play-protect/warning-dev-guidance
- https://support.google.com/googleplay/android-developer/answer/10964491
- https://support.google.com/googleplay/android-developer/answer/9844679
