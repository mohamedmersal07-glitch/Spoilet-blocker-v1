# SpoilerBlocker · Android TikTok prototype (v0.1)

**This is an Android Studio source project, not an APK.** A GitHub Actions workflow is provided to build an installable debug APK online. See **`GET_APK.md`** for step-by-step instructions.

SpoilerBlocker watches **text accessible from TikTok's UI** and displays a full-screen warning whenever on-screen TikTok text includes one of your blocked keywords. It does **not** modify TikTok, access TikTok's private APIs, or require root access.

## Included in this version

- A dark-mode Android app with an ON/OFF protection switch.
- Local add/remove keyword list, with an optional Avengers example.
- Prominent in-app Accessibility disclosure and affirmative consent.
- A user-activated Android Accessibility service.
- Matching against TikTok accessibility text, case-insensitive, including hashtags and phrase keywords.
- A full-screen **Possible spoiler detected** overlay with **View anyway** and **Skip video** actions.
- A local keyword test and warning preview inside the app.
- Automatic overlay cleanup when protection is turned off or when TikTok is no longer the foreground app (based on accessibility events).
- No account, no internet permission, no microphone, and no media capture.

## Important limitations

This is a **prototype**, not a guaranteed spoiler blocker.

1. **Late detection:** The TikTok video may already be visible or audible before Android delivers accessibility events; a spoiler can appear before the warning. No reliable pre-display interception is implemented.
2. **Text only:** Images, speech, video subtitles not exposed to Accessibility, and text embedded into video frames are **not detected**. No OCR or AI has been implemented.
3. **App-specific:** TikTok can change its interface and hide some content from Accessibility; the project needs testing on real devices. TikTok Global (`com.zhiliaoapp.musically`) and one regional package (`com.ss.android.ugc.trill`) are recognized.
4. **False positives:** Visible text in comments, usernames, overlays and UI elements may trigger warnings even if the video's subject is unrelated. Phrase matching uses simple substring search.
5. **Not tested on a TikTok device:** The local environment has no Android SDK, Gradle runtime, emulator, or connected Android phone. No APK was compiled locally. GitHub Actions can compile it using the provided workflow.
6. **Store review:** Google Play's Accessibility API policy requires a disclosure, explicit consent, declaration in Play Console and platform review. The in-app disclosure is provided, but distribution approval is not guaranteed. Do not claim `isAccessibilityTool=true` for this general-purpose app.

## Open / build in Android Studio

1. Install a recent [Android Studio](https://developer.android.com/studio) and SDK **Android API 35**.
2. Extract `SpoilerBlocker.zip` and **open the `SpoilerBlocker/` folder** (the folder containing `settings.gradle`) from Android Studio.
3. The project uses **Android Gradle Plugin 8.7.3**, **Gradle 8.9** and **JDK 17**. This export does not contain the binary Gradle wrapper, since that file was unavailable in the creation environment. If Android Studio asks you to configure Gradle, set up a local Gradle 8.9 installation, or run `gradle wrapper --gradle-version 8.9` once from the project root (with Gradle installed), then sync. This step needs internet to download build dependencies.
4. Connect a phone with USB debugging (or create an emulator), then click **Run** to install the debug app. Supports Android 8.0 (API 26) and later.
5. To generate a shareable debug APK, use **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The result is normally `app/build/outputs/apk/debug/app-debug.apk`.

## First-time setup on your Android phone

1. Open SpoilerBlocker.
2. Add `Avengers`, `Doomsday`, `Avengers Doomsday`, `Marvel` using the example button, or enter your own blocked terms.
3. Turn **Spoiler protection** ON and read the disclosure. Tap **I agree** only if you want to proceed.
4. In the Android Settings screen, find **Accessibility → Installed apps → SpoilerBlocker · TikTok filter** and enable the service. Settings names differ by phone.
5. Return to SpoilerBlocker. The state should show **ON · Watching for TikTok keywords**.
6. Tap **Test a caption** to verify your own keywords. Then open TikTok and test with captions containing those words.
7. When a warning appears, **View anyway** shows the same TikTok video; **Skip video** attempts a swipe to the next TikTok using Android's gesture system.
8. Turn protection OFF in SpoilerBlocker at any time, or disable its service in Android Accessibility Settings.

**If your phone blocks installing an app's accessibility service:** Android 13+ can restrict services for sideloaded APKs. Android Settings may offer a **Restricted settings** control in the installed app info menu. Only enable it if you understand and trust this app's source and behavior. Never disable device protection blindly.

## Technical architecture

```
MainActivity
   |  edits blocked keywords and ON/OFF preference
   v
SettingsStore (Android SharedPreferences, local JSON list)
   |  read on-device
   v
TikTokFilterService (AccessibilityService)
   |  detect TikTok events -> traverse accessible text nodes
   v
KeywordMatcher (pure Java, case-insensitive substring)
   |  match found
   v
WindowManager TYPE_ACCESSIBILITY_OVERLAY
   |  user chooses View anyway or Skip video
   v
AccessibilityService.dispatchGesture (for user-requested skip)
```

Only TikTok node trees are inspected for content. Other applications' foreground-app event metadata is used solely to hide the warning when you leave TikTok. The app intentionally declares **no INTERNET permission**.

## Test the keyword engine without Android tooling

On any PC with JDK 17+:

```bash
bash scripts/test-matcher.sh
```

This runs lightweight Java tests without Android dependencies. It **does not** test the Android UI, Accessibility service or TikTok integration.

## Developer notes / next milestones

- Test the accessible TikTok caption structure with an actual device on multiple TikTok versions.
- Improve per-video identity and swipe-change detection to avoid repeat warnings and false positives.
- Consider an **opt-in temporary veil while scrolling** and measure whether it meaningfully reduces spoiler exposure without causing frustrating delays.
- Experiment with optional on-device OCR via MediaProjection, subject to Android screen-capture consent and platform restrictions.
- Add optional semantic matching and audio detection only after confirming accuracy, privacy and device performance.
- Once TikTok functionality is validated, expand platform adapters to Instagram.

## Safety and privacy

This code is intended solely for the user's own screen filtering and requires the user's explicit Android permission. Do not disguise the accessibility service as a disability-support tool or use it to spy on other apps, read credentials, or covertly capture data.
