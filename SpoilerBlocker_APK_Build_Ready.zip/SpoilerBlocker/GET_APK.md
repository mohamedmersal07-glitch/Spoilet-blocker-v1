# Get an installable SpoilerBlocker APK

The ZIP contains **Android source code**, not a finished APK. It includes a GitHub Actions workflow that can compile an Android APK in the cloud without you installing Android Studio.

## Option A: Build through GitHub (no Android Studio)

1. Sign in to [GitHub](https://github.com/) and create a new repository, e.g. `SpoilerBlocker`. A private repository works too (subject to your GitHub Actions allowance).
2. Extract the downloaded SpoilerBlocker ZIP on your computer. Upload **the contents of the `SpoilerBlocker` folder**, including the hidden `.github` folder, into your new repository. The file `.github/workflows/build-android-apk.yml` must be present on the repository's main branch. Use **Add file → Upload files → Commit changes**, or push via Git.
3. On GitHub, open the repository's **Actions** tab. If prompted, enable Actions for this repository. Open **Build SpoilerBlocker APK** and use **Run workflow**, or let the workflow run after uploading files to `main`/`master`.
4. After the workflow **successfully finishes**, open the workflow run and look under **Artifacts** for **SpoilerBlocker-Android-APK**. Download that artifact ZIP and extract it.
5. The extracted file `app-debug.apk` is the Android installer. Move it to your Android phone and open it to install. Android may ask you to allow installation from that app/files browser.
6. Launch **SpoilerBlocker**, add your keywords, turn protection on, accept its Accessibility disclosure, and enable **SpoilerBlocker · TikTok filter** under Android Accessibility settings.

The GitHub action builds a **debug APK** signed with an automatically generated development key. It can be installed for personal testing but is not a Play Store release. For updates, APKs must be signed with the same key; GitHub's ephemeral debug key may change across builds. If you later want upgradeable releases, use a stable private release-signing key.

### Important troubleshooting

- If GitHub doesn't show the workflow, ensure `.github/workflows/build-android-apk.yml` was uploaded and committed on your repository's default branch.
- If the Android SDK fails to download, re-run the workflow. SDK installation requires external access on the GitHub runner.
- If Gradle fails, inspect the step logs; this project was not compiled in the creation environment because Android build tools are unavailable there.
- On Android 13+, sideloaded apps may have **Restricted settings** for Accessibility. Only change that setting if you trust the app and understand its permissions.

## Option B: Build with Android Studio on a computer

1. Install Android Studio with Java 17 and Android SDK Platform 35.
2. Open the extracted `SpoilerBlocker` folder as a project.
3. This project doesn't bundle a binary Gradle wrapper. If Android Studio requests Gradle configuration, use Gradle 8.9. An alternative from a terminal (if Gradle 8.9 is already installed) is `gradle wrapper --gradle-version 8.9` from the project root, followed by `./gradlew :app:assembleDebug` (or `gradlew.bat` on Windows).
4. Build via **Build → Build APK(s)** or run `gradle :app:assembleDebug`.
5. Installer output: `app/build/outputs/apk/debug/app-debug.apk`.

## What this app does and does NOT do

This is an early **text-only TikTok Accessibility filter**. The Android UI allows enabling/disabling filtering, adding keywords, previewing a warning, and trying to overlay warnings on TikTok caption text exposed by TikTok's Accessibility tree. Spoilers visible in video frames or spoken audio are not detected. The warning can appear too late to prevent seeing a spoiler. Its actual performance on TikTok has **not yet been tested on a device**.

It collects no TikTok account information, has no internet permission, and runs matching locally. Review the Accessibility disclosure before enabling it.
