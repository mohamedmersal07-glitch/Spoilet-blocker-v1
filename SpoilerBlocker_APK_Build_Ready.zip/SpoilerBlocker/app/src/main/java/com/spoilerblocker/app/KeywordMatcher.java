package com.spoilerblocker.app;

import java.text.Normalizer;
import java.util.Collection;
import java.util.Locale;

/** Dependency-free keyword matching. No text ever leaves this device. */
public final class KeywordMatcher {
    private KeywordMatcher() { }

    public static String normalize(String input) {
        if (input == null) return "";
        String text = Normalizer.normalize(input, Normalizer.Form.NFKC)
                .toLowerCase(Locale.ROOT);
        // Hide invisible formatting that may appear inside hashtags/captions.
        text = text.replaceAll("[\\u200B-\\u200D\\uFEFF]", "");
        return text.replaceAll("\\s+", " ").trim();
    }

    /** Returns the original keyword that matched, or null. */
    public static String firstMatch(String text, Collection<String> keywords) {
        String haystack = normalize(text);
        if (haystack.isEmpty() || keywords == null) return null;
        String compactHaystack = haystack.replaceAll("[^\\p{L}\\p{N}]", "");
        for (String keyword : keywords) {
            if (keyword == null) continue;
            String needle = normalize(keyword);
            if (needle.isEmpty()) continue;
            // Also catch variants such as #AvengersDoomsday or Avengers: Doomsday.
            String compactNeedle = needle.replaceAll("[^\\p{L}\\p{N}]", "");
            if (haystack.contains(needle) || (!compactNeedle.isEmpty() && compactHaystack.contains(compactNeedle))) {
                return keyword;
            }
        }
        return null;
    }
}
