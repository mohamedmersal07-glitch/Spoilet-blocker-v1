package com.spoilerblocker.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Text-only first prototype. Only TikTok accessibility trees are inspected.
 * A warning is applied after text becomes available; this is NOT pre-display
 * filtering, OCR, image recognition, or guaranteed spoiler prevention.
 */
public class TikTokFilterService extends AccessibilityService
        implements SharedPreferences.OnSharedPreferenceChangeListener {

    private static final String TIKTOK_GLOBAL = "com.zhiliaoapp.musically";
    private static final String TIKTOK_REGIONAL = "com.ss.android.ugc.trill";
    private static final int INK = 0xFF0A0F19;
    private static final int MINT = 0xFF65E7CF;
    private static final int LIGHT = 0xFFF1F6FC;
    private static final int SUBDUED = 0xFFAFBFD1;
    private static final int MAX_NODES = 260;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SettingsStore store;
    private WindowManager manager;
    private FrameLayout warningOverlay;
    private TextView matchedTermView;
    private String shownKeyword;
    private String shownContext;
    private String allowedContext;
    private String foregroundPackage;
    private boolean skipPending;

    private final Runnable scanRunnable = this::scanVisibleTikTok;

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        store = new SettingsStore(this);
        store.preferences().registerOnSharedPreferenceChangeListener(this);
        manager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || store == null) return;
        int type = event.getEventType();
        CharSequence rawPackage = event.getPackageName();
        String eventPackage = rawPackage == null ? "" : rawPackage.toString();

        // Inspect only TikTok. Other apps' foreground WINDOW events are used
        // solely to remove our warning when the user leaves TikTok.
        if (!isTikTok(eventPackage)) {
            if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                    && !getPackageName().equals(eventPackage)
                    && !"android".equals(eventPackage)
                    && !"com.android.systemui".equals(eventPackage)) {
                foregroundPackage = eventPackage;
                handler.removeCallbacks(scanRunnable);
                dismissWarning();
                allowedContext = null;
            }
            return;
        }

        foregroundPackage = eventPackage;
        if (!store.isEnabled() || !store.hasConsent()) {
            dismissWarning();
            return;
        }

        if (type == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            // A scroll often means a different video. Clear the user override.
            allowedContext = null;
            dismissWarning();
            // Waiting briefly lets TikTok expose the new caption in its tree.
            scheduleScan(120);
        } else if (type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            scheduleScan(90);
        }
    }

    private boolean isTikTok(String pkg) {
        return TIKTOK_GLOBAL.equals(pkg) || TIKTOK_REGIONAL.equals(pkg);
    }

    private void scheduleScan(long delayMs) {
        handler.removeCallbacks(scanRunnable);
        handler.postDelayed(scanRunnable, delayMs);
    }

    private void scanVisibleTikTok() {
        if (store == null || !store.isEnabled() || !store.hasConsent()
                || !isTikTok(foregroundPackage) || skipPending) {
            dismissWarning();
            return;
        }
        List<String> keywords = store.keywords();
        if (keywords.isEmpty()) { dismissWarning(); return; }
        AccessibilityNodeInfo root = findTikTokRoot();
        if (root == null) return; // Don't incorrectly dismiss while windows change.
        List<String> snippets = readVisibleText(root);
        if (snippets.isEmpty()) { dismissWarning(); return; }

        String matched = null;
        String context = null;
        for (String snippet : snippets) {
            matched = KeywordMatcher.firstMatch(snippet, keywords);
            if (matched != null) {
                // Use the text of the matched view as our per-video best-effort ID.
                context = KeywordMatcher.normalize(snippet);
                break;
            }
        }
        if (matched == null) {
            allowedContext = null;
            dismissWarning();
        } else if (context != null && context.equals(allowedContext)) {
            dismissWarning();
        } else {
            showWarning(matched, context);
        }
    }

    private AccessibilityNodeInfo findTikTokRoot() {
        try {
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows != null) {
                for (AccessibilityWindowInfo window : windows) {
                    if (window.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                    AccessibilityNodeInfo root = window.getRoot();
                    if (root != null && root.getPackageName() != null
                            && isTikTok(root.getPackageName().toString())) return root;
                }
            }
            AccessibilityNodeInfo active = getRootInActiveWindow();
            if (active != null && active.getPackageName() != null
                    && isTikTok(active.getPackageName().toString())) return active;
        } catch (SecurityException ignored) { }
        return null;
    }

    private List<String> readVisibleText(AccessibilityNodeInfo root) {
        List<String> result = new ArrayList<>();
        Set<String> unique = new HashSet<>();
        ArrayDeque<AccessibilityNodeInfo> pending = new ArrayDeque<>();
        pending.add(root);
        int examined = 0;
        while (!pending.isEmpty() && examined++ < MAX_NODES) {
            AccessibilityNodeInfo node = pending.removeFirst();
            CharSequence text = node.getText();
            CharSequence description = node.getContentDescription();
            addSnippet(result, unique, text);
            addSnippet(result, unique, description);
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) pending.addLast(child);
            }
        }
        return result;
    }

    private void addSnippet(List<String> result, Set<String> unique, CharSequence raw) {
        if (raw == null) return;
        String text = raw.toString().trim();
        if (!text.isEmpty() && unique.add(text)) result.add(text);
    }

    private void showWarning(String keyword, String context) {
        if (warningOverlay != null) {
            shownContext = context;
            if (!keyword.equals(shownKeyword)) {
                shownKeyword = keyword;
                matchedTermView.setText("Matched keyword: " + keyword);
            }
            return;
        }
        shownKeyword = keyword;
        shownContext = context;
        FrameLayout veil = new FrameLayout(this);
        veil.setBackgroundColor(0xF90A0F19);
        veil.setClickable(true);
        veil.setFocusable(false);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), dp(29), dp(24), dp(25));
        content.setBackground(round(0xFF172333, 22, 0xFF34505A));

        TextView shield = text("✦", 42, MINT, true);
        shield.setGravity(Gravity.CENTER);
        content.addView(shield);
        spacer(content, 10);
        TextView eyebrow = text("SPOILERBLOCKER ACTIVE", 11, MINT, true);
        eyebrow.setGravity(Gravity.CENTER);
        content.addView(eyebrow);
        spacer(content, 12);
        TextView heading = text("Possible spoiler\ndetected", 26, LIGHT, true);
        heading.setGravity(Gravity.CENTER);
        content.addView(heading);
        spacer(content, 12);
        TextView info = text("This TikTok contains text related to a topic you've blocked.", 14, SUBDUED, false);
        info.setGravity(Gravity.CENTER);
        content.addView(info);
        spacer(content, 17);
        matchedTermView = text("Matched keyword: " + keyword, 13, MINT, true);
        matchedTermView.setGravity(Gravity.CENTER);
        matchedTermView.setPadding(dp(9), dp(11), dp(9), dp(11));
        matchedTermView.setBackground(round(0xFF243E46, 12, 0));
        content.addView(matchedTermView);
        spacer(content, 23);
        Button reveal = button("View anyway", true);
        reveal.setOnClickListener(v -> {
            allowedContext = shownContext;
            dismissWarning();
        });
        content.addView(reveal);
        spacer(content, 10);
        Button skip = button("Skip video  ↑", false);
        skip.setOnClickListener(v -> skipVideo());
        content.addView(skip);
        spacer(content, 12);
        TextView note = text("Text-only beta · Some spoilers may be missed.", 11, 0xFF8094A9, false);
        note.setGravity(Gravity.CENTER);
        content.addView(note);

        FrameLayout.LayoutParams cardParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        cardParams.leftMargin = dp(21);
        cardParams.rightMargin = dp(21);
        veil.addView(content, cardParams);
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.setTitle("SpoilerBlocker spoiler warning");
        try {
            manager.addView(veil, params);
            warningOverlay = veil;
        } catch (RuntimeException e) {
            warningOverlay = null;
            matchedTermView = null;
        }
    }

    private void skipVideo() {
        // Remove the touch-blocking warning before sending a swipe to TikTok.
        allowedContext = shownContext;
        skipPending = true;
        dismissWarning();
        handler.postDelayed(() -> {
            if (!isTikTok(foregroundPackage) || !store.isEnabled()) {
                skipPending = false;
                return;
            }
            int width = getResources().getDisplayMetrics().widthPixels;
            int height = getResources().getDisplayMetrics().heightPixels;
            Path path = new Path();
            path.moveTo(width * 0.5f, height * 0.79f);
            path.lineTo(width * 0.5f, height * 0.25f);
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, 350))
                    .build();
            try {
                boolean started = dispatchGesture(gesture, new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription description) {
                        handler.postDelayed(() -> {
                            skipPending = false;
                            allowedContext = null;
                            scheduleScan(150);
                        }, 200);
                    }
                    @Override public void onCancelled(GestureDescription description) {
                        skipPending = false;
                        allowedContext = null;
                        scheduleScan(150);
                    }
                }, handler);
                if (!started) {
                    skipPending = false;
                    allowedContext = null;
                    scheduleScan(150);
                }
            } catch (SecurityException e) {
                skipPending = false;
                allowedContext = null;
                scheduleScan(150);
            }
        }, 140);
    }

    private void dismissWarning() {
        if (warningOverlay == null) return;
        try { manager.removeViewImmediate(warningOverlay); }
        catch (IllegalArgumentException ignored) { }
        warningOverlay = null;
        matchedTermView = null;
        shownKeyword = null;
        shownContext = null;
    }

    @Override public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
        if (SettingsStore.KEY_ENABLED.equals(key) && !store.isEnabled()) {
            handler.removeCallbacks(scanRunnable);
            allowedContext = null;
            dismissWarning();
        } else if (store.isEnabled()) {
            allowedContext = null;
            scheduleScan(150);
        }
    }

    @Override public void onInterrupt() {
        handler.removeCallbacks(scanRunnable);
        dismissWarning();
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(scanRunnable);
        if (store != null) store.preferences().unregisterOnSharedPreferenceChangeListener(this);
        dismissWarning();
        super.onDestroy();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        text.setLineSpacing(dp(3), 1.05f);
        return text;
    }
    private Button button(String label, boolean primary) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(label);
        button.setTextColor(primary ? INK : LIGHT);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setBackground(round(primary ? MINT : 0xFF263447, 13, primary ? 0 : 0xFF607084));
        button.setMinHeight(dp(52));
        button.setStateListAnimator(null);
        return button;
    }
    private GradientDrawable round(int color, int radius, int border) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        if (border != 0) shape.setStroke(dp(1), border);
        return shape;
    }
    private void spacer(LinearLayout parent, int h) {
        parent.addView(new View(this), new LinearLayout.LayoutParams(1, dp(h)));
    }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
