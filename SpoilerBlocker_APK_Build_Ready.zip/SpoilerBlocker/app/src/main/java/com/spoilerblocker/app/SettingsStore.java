package com.spoilerblocker.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class SettingsStore {
    static final String FILE = "spoilerblocker_prefs";
    static final String KEY_ENABLED = "protection_enabled";
    static final String KEY_CONSENT = "accessibility_disclosure_accepted";
    private static final String KEY_TERMS = "blocked_terms";

    private final SharedPreferences prefs;

    SettingsStore(Context context) {
        prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
        if (!prefs.contains(KEY_TERMS)) {
            saveKeywords(Collections.emptyList());
        }
    }

    SharedPreferences preferences() { return prefs; }
    boolean isEnabled() { return prefs.getBoolean(KEY_ENABLED, false); }
    boolean hasConsent() { return prefs.getBoolean(KEY_CONSENT, false); }
    void setEnabled(boolean value) { prefs.edit().putBoolean(KEY_ENABLED, value).apply(); }
    void acceptConsent() { prefs.edit().putBoolean(KEY_CONSENT, true).apply(); }

    List<String> keywords() {
        List<String> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs.getString(KEY_TERMS, "[]"));
            for (int i = 0; i < array.length(); i++) {
                String term = array.optString(i, "").trim();
                if (!term.isEmpty()) result.add(term);
            }
        } catch (JSONException ignored) { }
        return result;
    }

    void saveKeywords(List<String> terms) {
        JSONArray array = new JSONArray();
        for (String term : terms) array.put(term);
        prefs.edit().putString(KEY_TERMS, array.toString()).apply();
    }
}
