#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/selftest
javac -d build/selftest app/src/main/java/com/spoilerblocker/app/KeywordMatcher.java scripts/KeywordMatcherSelfTest.java
java -cp build/selftest KeywordMatcherSelfTest
