import com.spoilerblocker.app.KeywordMatcher;
import java.util.Arrays;

public class KeywordMatcherSelfTest {
    private static int checks = 0;
    private static void check(boolean actual, String message) {
        checks++;
        if (!actual) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        var terms = Arrays.asList("Avengers", "Doomsday", "Avengers Doomsday", "Marvel");
        check("Avengers".equals(KeywordMatcher.firstMatch("#AVENGERS trailer", terms)), "hashtag and case");
        check("Marvel".equals(KeywordMatcher.firstMatch("New MARVEL leak", terms)), "case-insensitive");
        check(KeywordMatcher.firstMatch("Cat videos for you", terms) == null, "unrelated video");
        check("Avengers".equals(KeywordMatcher.firstMatch("Aven\u200Bgers leak", terms)), "invisible chars");
        check("Doomsday".equals(KeywordMatcher.firstMatch("DOOMSDAY   scenes", terms)), "whitespace");
        check(KeywordMatcher.firstMatch("", terms) == null, "empty content");
        check(KeywordMatcher.firstMatch("Marvel", Arrays.asList(" ")) == null, "blank keyword");
        check("Avengers Doomsday".equals(KeywordMatcher.firstMatch("avengers   doomsday", Arrays.asList("Avengers Doomsday"))), "phrases");
        check("Avengers Doomsday".equals(KeywordMatcher.firstMatch("#AvengersDoomsday", Arrays.asList("Avengers Doomsday"))), "joined hashtags");
        check("Avengers Doomsday".equals(KeywordMatcher.firstMatch("Avengers: Doomsday", Arrays.asList("Avengers Doomsday"))), "punctuated titles");
        System.out.println("PASS: " + checks + " keyword-matching tests");
    }
}
